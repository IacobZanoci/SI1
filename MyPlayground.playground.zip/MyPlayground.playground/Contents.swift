import Foundation
import CommonCrypto

// criptare/decriptare errors
enum AESError: Error {
    case keySizeError
    case keyDataError
}

// implementează
public struct AES256 {
    private let key: Data

    // Inițializatorul structurii care primește o cheie sub formă de șir de caractere
    public init?(key: String) throws {
        // check key length (256 biți)
        guard key.count == kCCKeySizeAES256 else {
            throw AESError.keySizeError
        }
        // sir de caractere into data format
        guard let keyData = key.data(using: .utf8) else {
            throw AESError.keyDataError
        }
        self.key = keyData
    }

    public func encrypt(messageData: Data?) -> Data? {
        // check input data
        guard let messageData = messageData else { return nil }
        // encrypt data with specified key
        return crypt(data: messageData, option: CCOperation(kCCEncrypt))
    }

    // decryption method
    public func decrypt(encryptedData: Data?) -> Data? {
        // decryption function to decrypt data
        return crypt(data: encryptedData, option: CCOperation(kCCDecrypt))
    }

    // Funcție privată care efectuează operații de criptare și decriptare
    private func crypt(data: Data?, option: CCOperation) -> Data? {
        // Verifică dacă există date de intrare
        guard let data = data else { return nil }
        // Inițializează un buffer de ieșire pentru rezultatul criptării/decriptării (store)
        var outputBuffer = [UInt8](repeating: 0, count: data.count + kCCBlockSizeAES128)
        var numBytesEncrypted = 0
        // Folosește funcția CCCrypt din CommonCrypto pentru criptare/decriptare
        let status = CCCrypt(
            option,
            CCAlgorithm(kCCAlgorithmAES),
            CCOptions(kCCOptionPKCS7Padding),
            Array(key),
            kCCKeySizeAES256,
            nil,
            Array(data),
            data.count,
            &outputBuffer, outputBuffer.count, &numBytesEncrypted
        )
        // Verifică starea operației de criptare/decriptare
        guard status == kCCSuccess else { return nil }
        // Preia rezultatul într-un buffer de ieșire și returnează sub formă de Data
        let outputBytes = outputBuffer.prefix(numBytesEncrypted)
        return Data(outputBytes)
    }
}

let message = "just testing"
let data = message.data(using: .utf8)
let key = "Uc1gU2FsdGVkX19LW0ZSbvKUJT6TnTfI"

print("Text to be Encrypted: \(message)")
print("Secret Key: \(key)")

if let encryptedData = try? AES256(key: key)?.encrypt(messageData: data) {
    print("AES Encrypted Data: \(encryptedData.base64EncodedString())")
    if let decryptedData = try? AES256(key: key)?.decrypt(encryptedData: encryptedData) {
        let decryptedMessage = String(data: decryptedData, encoding: .utf8)
        if decryptedMessage == message {
            print("AES Decrypted Message: \(decryptedMessage ?? "")")
            print("Encryption and decryption successful")
        } else {
            print("Encryption and decryption failed")
        }
    } else {
        print("AES Decryption failed")
    }
} else {
    print("AES Encryption failed")
}
